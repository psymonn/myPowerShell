
function Remove-TFLHelp {
# .ExternalHelp Remove-TFLHelp-help.xml 

"Removing TFLHelp module"
Remove-Module TFLHelp
}
