#  TFLHelp.Psm1
#
#  Additional function
Function Get-TFLHelpDetails {
<#
.SYNOPSIS 
    Simple Function in Module
.DESCRIPTION
    This function is indside a .PSM1 file that is imported with the module. Help
    online points to bt.etree.org's GD show index.
.EXAMPLE
    Left as an Exercise for the reader
.LINK
    http://bt.etree.org/?searchsss=&cat=8
#>
" In get-tflhelpdetails"
}