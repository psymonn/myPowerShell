<#
.SYNOPSIS
   Tthis is help synopsis for Help1

.DESCRIPTION
   Some inline comment based help in a script

.EXAMPLE
   Get-Help help1.ps1
   Produces some output - an exercise for the reader

.EXAMPLE
   Get-Help help1.ps1 -online
   Produces some online output

.LINK
   http://pshscripts.blogspot.com
#>


"In Help1"