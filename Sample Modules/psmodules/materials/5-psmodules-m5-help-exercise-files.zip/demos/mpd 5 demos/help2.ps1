function get-cbh {
<#
.SYNOPSIS
   This is help synopsis for function get-cbh
.DESCRIPTION
   Some inline comment based help for a function Note the
   link points to ETree.Org's collection of live GD recordings!
.EXAMPLE
   Get-help Get-Cbh

   Produces some output - details are an exercise for the reader
.EXAMPLE
   Get-help get-cbh -online
   Takes you to Bt.Etree.Org - where you can download more GD Shows!
.LINK
   http://bt.etree.org/?searchsss=&cat=8
#>
"In the get-cbh function - You just need a Grateful Dead show or two"
}