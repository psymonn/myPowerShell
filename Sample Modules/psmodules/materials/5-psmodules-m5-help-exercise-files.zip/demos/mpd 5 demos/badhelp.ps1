<#
. synopsis
   this is help synopsis

.DESCRIPTION
   Some inline comment based help in a script

. EXAMPLE
   Get-Help help1.ps1
   Produces some output - an exercise for the reader

.LINK
   http://pshscripts.blogspot.com
#>

" In BADHELP.PS1"

