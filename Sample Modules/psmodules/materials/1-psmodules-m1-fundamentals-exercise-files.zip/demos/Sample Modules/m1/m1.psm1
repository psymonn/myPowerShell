# PowerShell module m1
function get-greeting {
"hello world"
}