# $mod\m2\M2.psm1
# For M2 of Pluralsight Creating PowerShell Modules Course
#

function get-greeting {
"hello world from the m2 module"
}